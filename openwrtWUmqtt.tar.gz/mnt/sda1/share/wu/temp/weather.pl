#!/usr/bin/perl
#use strict;
use warnings;
my $rec = `/bin/sed -n 2p /tmp/weather | sed 's/([^)]*)//gi'`;
#print "$rec";    
      `/usr/bin/mosquitto_pub -h 192.168.168.150 -t 'WCT' -m '$rec'`;

$rec = `/bin/sed -n 3p /tmp/weather`;
#print "$rec";
      `/usr/bin/mosquitto_pub -h 192.168.168.150 -t 'WCW' -m '$rec'`;

$rec = `/bin/sed -n 4p /tmp/weather`;
#print "$rec";
      `/usr/bin/mosquitto_pub -h 192.168.168.150 -t 'WCH' -m '$rec'`;

$rec = `/bin/sed -n 9p /tmp/weather`;
#print "$rec";
      `/usr/bin/mosquitto_pub -h 192.168.168.150 -t 'WF1' -m '$rec'`;

$rec = `/bin/sed -n 10p /tmp/weather`;
#print "$rec";
      `/usr/bin/mosquitto_pub -h 192.168.168.150 -t 'WF2' -m '$rec'`;

$rec = `/bin/sed -n 9,11p /tmp/weather`;
#print "$rec";
      `/usr/bin/mosquitto_pub -h 192.168.168.150 -t 'WF3' -m '$rec'`;


print "\ndone :)";

